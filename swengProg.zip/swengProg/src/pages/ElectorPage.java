package pages;

import java.util.Vector;

import application.Candidato;
import application.CategoricalPrefVote;
import application.CategoricalVote;
import application.OrdinalVote;
import application.Querys;
import application.ReferendumVote;
import application.Session;
import application.userLogged;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ElectorPage extends Pages {
	private static Vector<Session> sess;
	
	
	
	
	public ElectorPage() {
		super();
	}
	
	
	@Override
	public void show() {
		try {
			System.out.println("Switch main1");
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/MainPage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			System.out.println("Switch main2");
			
			fillSessions();
			
			if((new userLogged()).isAdmin())
				((Button)scene.lookup("#adminButton")).setVisible(true);
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillSessions() {
		sess = Querys.getSessions();
		
		ListView lv = (ListView)scene.lookup("#sessionList");
		
		for(int i=0; i<sess.size(); i++) {
			String s = "";
			if( sess.get(i).getIsActive() ) {
				if(sess.get(i).getAlreadyVoted())
					s = "|| VOTATO || ";
			}
			else {
				s = "|| SCADUTA || ";
			}
			s += sess.get(i).toString();
			lv.getItems().add(s);
		}
	}
	
	
	
	
	public void sessionClick(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		System.out.println("Sessione click " + selectedSession );
		
		if(sess != null) {
			Button b = (Button)scene.lookup("#voteButton");
			if(sess.get(selectedSession).getAlreadyVoted() || !sess.get(selectedSession).getIsActive())
				b.setDisable(true);
			else
				b.setDisable(false);
			
			Label ss = (Label)scene.lookup("#sessionStatus");
			if(!sess.get(selectedSession).getIsActive()) {
				
				if(sess.get(selectedSession).isReferendum()) {
					int winner = Querys.getWinnerRef(sess.get(selectedSession));
					ss.setText("Risultato referendum: Maggioranza per il " + (winner==1?"SI":(winner==2?"NO":"Errore")));
				}
				else {
					Candidato candVincente = Querys.getWinner(sess.get(selectedSession));
					ss.setText("Risultato elezione: " + candVincente.toString());
				}
			}
			else if(sess.get(selectedSession).getAlreadyVoted())
				ss.setText("Hai già inviato il tuo voto per questa sessione");
			else
				ss.setText("Clicca vota per procedere alla votazione");
		}
	}
	
	public void voteClick(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		
		System.out.println("Vota: "+sess.get(selectedSession).getClass().getSimpleName());
		
		if(sess.get(selectedSession) instanceof OrdinalVote) {
			(new OrdinalVotePage(sess.get(selectedSession))).show();
		}
		else if(sess.get(selectedSession) instanceof CategoricalVote) {
			(new CategoricalVotePage(sess.get(selectedSession))).show();
		}
		else if(sess.get(selectedSession) instanceof CategoricalPrefVote) {
			(new CategoricalVotePrefPage(sess.get(selectedSession))).show();
		}
		else if(sess.get(selectedSession) instanceof ReferendumVote) {
			(new ReferendumVotePage(sess.get(selectedSession))).show();
		}
	}

	
	
	public void adminClicked(MouseEvent e) {
		(new AdminPage()).show();
	}
	
	
	public void logoutClicked(MouseEvent e) {
		(new userLogged()).logout();
		(new LoginPage()).show();
	}
	
	
}



