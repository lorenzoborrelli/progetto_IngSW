package pages;

import java.util.Vector;

import application.CategoricalPrefVote;
import application.CategoricalVote;
import application.OrdinalVote;
import application.Querys;
import application.ReferendumVote;
import application.Session;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ElectorPage extends Pages {
	private static Vector<Session> sess;
	
	
	
	
	public ElectorPage() {
		super();
	}
	
	
	@Override
	public void show() {
		try {
			System.out.println("Switch main1");
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/MainPage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			System.out.println("Switch main2");
			
			fillSessions();
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillSessions() {
		sess = Querys.getSessions();
		
		ListView lv = (ListView)scene.lookup("#sessionList");
		
		for(int i=0; i<sess.size(); i++)
			lv.getItems().add(sess.get(i).toString());
	}
	
	
	
	
	public void sessionClick(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		System.out.println("Sessione click " + selectedSession );
		
		if(sess != null) {
			// controllo se non è già stata votata
			Button b = (Button)scene.lookup("#voteButton");
			b.setDisable(false);
		}
	}
	
	public void voteClick(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		
		System.out.println("Vota: "+sess.get(selectedSession).getClass().getSimpleName());
		
		if(sess.get(selectedSession) instanceof OrdinalVote) {
			(new OrdinalVotePage()).show();
		}
		else if(sess.get(selectedSession) instanceof CategoricalVote) {
			(new CategoricalVotePage()).show();
		}
		else if(sess.get(selectedSession) instanceof CategoricalPrefVote) {
			(new CategoricalPrefVotePage()).show();
		}
		else if(sess.get(selectedSession) instanceof ReferendumVote) {
			(new ReferendumVotePage()).show();
		}
	}
}



