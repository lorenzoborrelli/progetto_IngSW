package pages;

public class AdminPage {

}
