package pages;

public class CategoricalPrefVotePage extends Pages {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}
