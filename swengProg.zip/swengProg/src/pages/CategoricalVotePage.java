package pages;

import java.util.Vector;

import application.Candidato;
import application.Partito;
import application.Querys;
import application.Session;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class CategoricalVotePage extends Pages {
	private static Session s;
	private static Vector<Candidato> candidates;
	private static Vector<Partito> factions;
	private static int isCandOrFact = 0;	// 1-> candidates, 2->factions

	public CategoricalVotePage() {}
	public CategoricalVotePage(Session s) {
		this.s = s;
	}
	
	@Override
	public void show() {
		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/OrdinalVotePage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			
			fillCand();
			Label title = (Label)scene.lookup("#title");
			title.setText("Elezione ordinale "+s.getName());
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillCand() {
		ListView lv = (ListView)scene.lookup("#list");
		lv.getItems().clear();
		
		candidates = Querys.getCandidates();
		factions = Querys.getFactions();
		if(candidates.size() > 0 && factions.size() == 0) {		// se ci sono i candidati stampa quelli, se ci sono i partiti stampa quelli
			isCandOrFact = 1;
		}
		else if(candidates.size() == 0 && factions.size() > 0) {		// se ci sono i candidati stampa quelli, se ci sono i partiti stampa quelli
			isCandOrFact = 2;
		}
		else {
			System.out.println("Error Candidates Factions");
			Label title = (Label)scene.lookup("#title");
			title.setText("Errore di sistema");
		}
	}
	
	
	public void sessionClicked(MouseEvent e) {
		Button up = (Button)scene.lookup("#up");
		Button down = (Button)scene.lookup("#down");
		up.setDisable(false);
		down.setDisable(false);
	}
	
	
	
	public void confirmClicked(MouseEvent e) {
		Querys.setCategoricalVote(candidates, factions);
		
		(new ElectorPage()).show();
	}

}
