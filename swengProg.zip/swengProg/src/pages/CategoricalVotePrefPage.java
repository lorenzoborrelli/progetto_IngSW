package pages;

import java.util.Vector;

import application.Candidato;
import application.Partito;
import application.Querys;
import application.Session;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class CategoricalVotePrefPage extends Pages {
	private static Session s;
	private static Vector<Candidato> candidates;
	private static Vector<Partito> factions;
	private static int selectedFaction;

	public CategoricalVotePrefPage() {}
	public CategoricalVotePrefPage(Session s) {
		this.s = s;
	}
	
	@Override
	public void show() {
		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/CategoricalVotePrefPage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			
			fillCand();
			Label title = (Label)scene.lookup("#title");
			title.setText("Elezione ordinale "+s.getName());
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillCand() {
		ListView lvF = (ListView)scene.lookup("#listFactions");
		
		factions = Querys.getFactions();

		for(int i=0; i<factions.size(); i++) {
			lvF.getItems().add(factions.get(i).toString());
		}
	}

	

	public void sessionFactClicked(MouseEvent e) {		// riempie la lista dei candidati quando l'utente clicca su un partito
		ListView lvF = (ListView)scene.lookup("#listFactions");
		selectedFaction = lvF.getSelectionModel().getSelectedIndex();
		
		candidates = Querys.getCandidates(factions.get(selectedFaction));
		ListView lvC = (ListView)scene.lookup("#listCanditates");
		for(int i=0; i<candidates.size(); i++) {
			lvC.getItems().add(candidates.get(i).toString());
		}
	}
	
	public void sessionCandClicked(MouseEvent e) {
		
	}
	
	
	
	
	public void confirmClicked(MouseEvent e) {
		Querys.setCategoricalPrefVote(candidates, factions);
		
		(new ElectorPage()).show();
	}

}
