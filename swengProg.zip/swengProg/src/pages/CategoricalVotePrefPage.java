package pages;

import java.util.Vector;

import application.Candidato;
import application.Partito;
import application.Querys;
import application.Session;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.MouseEvent;

public class CategoricalVotePrefPage extends Pages {
	private static Session s;
	private static Vector<Candidato> candidates;
	private static Vector<Partito> factions;

	public CategoricalVotePrefPage() {}
	public CategoricalVotePrefPage(Session s) {
		this.s = s;
	}
	
	@Override
	public void show() {
		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/CategoricalVotePrefPage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			
			fillCand();
			Label title = (Label)scene.lookup("#title");
			title.setText("Elezione categorica "+s.getName());
			
			((ListView)scene.lookup("#sessionCList")).getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillCand() {
		candidates = Querys.getCandidates(s);
		factions = Querys.getFactions(s);
		
		ListView lvF = (ListView)scene.lookup("#sessionFList");
		ListView lvC = (ListView)scene.lookup("#sessionCList");
		lvF.getItems().clear();
		lvC.getItems().clear();

		for(int i=0; i<factions.size(); i++) {
			lvF.getItems().add(factions.get(i).toString());
		}
		
	}
	
	
	public void sessionFClicked(MouseEvent e) {
		
		ListView lvC = (ListView)scene.lookup("#sessionCList");
		ListView lvF = (ListView)scene.lookup("#sessionFList");
		
		lvC.getItems().clear();
		
		for(int i=0; i<candidates.size(); i++) {
			if(candidates.get(i).getPartito().equals( factions.get(lvF.getSelectionModel().getSelectedIndex()) ))
				lvC.getItems().add(candidates.get(i).toString());
		}
		
	}
	
	public void sessionCClicked(MouseEvent e) {
		Button conf = (Button)scene.lookup("#confirmButton");
		conf.setDisable(false);
		
		
	}
	
	
	
	public void confirmClicked(MouseEvent e) {
		ListView lvF = (ListView)scene.lookup("#sessionFList");
		ListView lvC = (ListView)scene.lookup("#sessionCList");
		
		Vector<Candidato> cc = new Vector<Candidato>();
		
		ObservableList indexes = lvC.getSelectionModel().getSelectedIndices();
		
		for(int i=0; i<indexes.size(); i++) {
			cc.add( candidates.get( (int) indexes.get(i) ) );
		}
		
		Querys.setCategoricalPrefVote(s, cc);
		
		(new ElectorPage()).show();
	}
}
