package pages;

public class RegistrationPage extends Pages {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}
