package pages;

import java.util.Vector;

import application.Candidato;
import application.Partito;
import application.Querys;
import application.Session;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class OrdinalVotePage extends Pages {
	private static Session s;
	private static Vector<Candidato> candidates;
	private static Vector<Partito> factions;
	private static int isCandOrFact = 0;	// 1-> candidates, 2->factions

	public OrdinalVotePage() {}
	public OrdinalVotePage(Session s) {
		this.s = s;
	}
	
	@Override
	public void show() {
		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/OrdinalVotePage.fxml"));
			scene = new Scene(mainRoot);
			getStage().setScene(scene);
			getStage().show();
			
			fillCand();
			Label title = (Label)scene.lookup("#title");
			title.setText("Elezione ordinale "+s.getName());
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
	}
	
	public void fillCand() {
		ListView lv = (ListView)scene.lookup("#list");
		lv.getItems().clear();
		
		candidates = Querys.getCandidates();
		factions = Querys.getFactions();
		if(candidates.size() > 0 && factions.size() == 0) {		// se ci sono i candidati stampa quelli, se ci sono i partiti stampa quelli
			isCandOrFact = 1;
		}
		else if(candidates.size() == 0 && factions.size() > 0) {		// se ci sono i candidati stampa quelli, se ci sono i partiti stampa quelli
			isCandOrFact = 2;
		}
		else {
			System.out.println("Error Candidates Factions");
			Label title = (Label)scene.lookup("#title");
			title.setText("Errore di sistema");
		}
	}
	
	
	public void sessionClicked(MouseEvent e) {
		Button up = (Button)scene.lookup("#up");
		Button down = (Button)scene.lookup("#down");
		up.setDisable(false);
		down.setDisable(false);
	}
	
	public void upClicked(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		
		if(isCandOrFact == 1) {
			if(selectedSession > 0) {
				Candidato temp = candidates.get(selectedSession);
				candidates.set(selectedSession, candidates.get(selectedSession-1));
				candidates.set(selectedSession-1, temp);
			}
		}
		else if(isCandOrFact == 2) {
			if(selectedSession > 0) {
				Partito temp = factions.get(selectedSession);
				factions.set(selectedSession, factions.get(selectedSession-1));
				factions.set(selectedSession-1, temp);
			}
		}
	}
	
	
	
	
	public void downClicked(MouseEvent e) {
		ListView lv = (ListView)scene.lookup("#sessionList");
		int selectedSession = lv.getSelectionModel().getSelectedIndex();
		
		if(isCandOrFact == 1) {
			if(selectedSession < factions.size()-1) {
				Candidato temp = candidates.get(selectedSession);
				candidates.set(selectedSession, candidates.get(selectedSession-1));
				candidates.set(selectedSession+1, temp);
			}
		}
		else if(isCandOrFact == 2) {
			if(selectedSession < factions.size()-1) {
				Partito temp = factions.get(selectedSession);
				factions.set(selectedSession, factions.get(selectedSession-1));
				factions.set(selectedSession+1, temp);
			}
		}
	}
	
	public void confirmClicked(MouseEvent e) {
		Querys.setOrdinalVote(candidates, factions);
		
		(new ElectorPage()).show();
	}

}
