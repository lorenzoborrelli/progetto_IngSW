package application;

public abstract class Session {
	private int id;
	protected String name;
	
	public Session(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public abstract String toString();
	
}
