package application;

import java.util.Vector;

public class OrdinalVote extends Session{
	private Vector<Partito> partiti;
	private Vector<Candidato> candidati;
	
	public OrdinalVote(String name){
		super(name);
		partiti = new Vector<Partito>();
	}
	
	public String toString(){
		String s = "Votazione ordinale \""+name+"\"";
		return s;
	}
	
}
