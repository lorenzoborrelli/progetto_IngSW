package application;

import dbManagement.DBConnector;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.Vector;


public class Querys {
	private static DBConnector db;
	
	public Querys(){
		db = new DBConnector();
	}
	
	public static Vector<Session> getSessions(){
		Vector<Session> ss = new Vector<Session>();
		String query = "SELECT s.id, s.name AS nomeSessione, vt.name AS tipoSessione FROM session s, voteType vt WHERE idVoteType=vt.id;";		// mostrare solo le sessioni di userLogged
		
		try {
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
				rowcount = rs.getRow();
				rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			for(int i=0; i<rowcount; i++){
				rs.next();
				//rs.getString()	// da fare le query e il riempimento della sessione adatta
				String sessione = rs.getString("tipoSessione");
				Session s = null;
				if(sessione.equals("votoOrdinale")){
					s = new OrdinalVote(rs.getString("nomeSessione"));
				}
				else if(sessione.equals("votoCategorico")){
					s = new CategoricalVote(rs.getString("nomeSessione"));
				}
				else if(sessione.equals("votoCategoricoPref")){
					s = new CategoricalVote(rs.getString("nomeSessione"));
				}
				else if(sessione.equals("referendum")){
					s = new ReferendumVote(rs.getString("nomeSessione"));
				}
				else{
					continue;
				}
				ss.add(s);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ss;
	}
	
	
	public static void insertUser(){
		String query = "INSERT INTO User() VALUES ;";
		db.insertQuery(query);
	}
	
	
	public static User checkCredentials(String email, String psw){
		String query = "SELECT id,name,surname,email,type FROM user INNER JOIN credential ON idUser=user.id WHERE email LIKE \""+email+"\" AND password = \""+psw+"\";";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			//System.out.println();
			
			if( rowcount == 0){
				System.out.println("Utente non trovato");
				return null;
			}
			
			rs.next();
			User u = new User(rs.getInt("id"), rs.getString("name"), rs.getString("surname"), email, rs.getInt("type"));
			
			System.out.println("Credenziali valide");
			return u;
		} catch (SQLSyntaxErrorException e) {
			System.out.println("Errore controllo credenziali "+e.getMessage());
			//e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Errore controllo credenziali "+e.getMessage());
			//e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Errore controllo credenziali "+e.getMessage());
			//e.printStackTrace();
		}
		
		return null;
	}

	public static Vector<Candidato> getCandidates() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Vector<Partito> getFactions() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setOrdinalVote(Vector<Candidato> candidates, Vector<Partito> factions) {
		// TODO Auto-generated method stub
		
	}

	public static void setCategoricalVote(Vector<Candidato> candidates, Vector<Partito> factions) {
		// TODO Auto-generated method stub
		
	}

	public static void setReferendumVote(int yesOrNo) {
		// TODO Auto-generated method stub
		
	}

	public static Vector<Candidato> getCandidates(Partito partito) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setCategoricalPrefVote(Vector<Candidato> candidates, Vector<Partito> factions) {
		// TODO Auto-generated method stub
		
	}
}
