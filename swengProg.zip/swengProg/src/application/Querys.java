package application;

import dbManagement.DBConnector;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.Vector;


public class Querys {
	private static DBConnector db;
	
	public Querys(){
		db = new DBConnector();
	}
	
	public static Vector<Session> getSessions(){
		Vector<Session> ss = new Vector<Session>();
		String query = 		"SELECT s.id AS idSess, s.name AS nomeSessione, vt.name AS tipoSessione, s.isActive AS isActive, (SELECT COUNT(vv.id) FROM vervote vv WHERE idUser="+(new userLogged()).getUtente().getId()+" AND idSession=s.id) AS alreadyVoted "
						+ 	"FROM session s, voteType vt "
						+ 	"WHERE idVoteType=vt.id;";		// mostrare solo le sessioni di userLogged
		System.out.println(query);
		try {
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			
			int rowcount = 0;
			if (rs.last()) {
				rowcount = rs.getRow();
				rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			for(int i=0; i<rowcount; i++){
				rs.next();
				//rs.getString()	// da fare le query e il riempimento della sessione adatta
				String sessione = rs.getString("tipoSessione");
				Session s = null;
				if(sessione.equals("votoOrdinale")){
					s = new OrdinalVote(Integer.parseInt(rs.getString("idSess")), rs.getString("nomeSessione"), rs.getBoolean("isActive"));
				}
				else if(sessione.equals("votoCategorico")){
					s = new CategoricalVote(Integer.parseInt(rs.getString("idSess")), rs.getString("nomeSessione"), rs.getBoolean("isActive"));
				}
				else if(sessione.equals("votoCategoricoPref")){
					s = new CategoricalVote(Integer.parseInt(rs.getString("idSess")), rs.getString("nomeSessione"), rs.getBoolean("isActive"));
				}
				else if(sessione.equals("referendum")){
					s = new ReferendumVote(Integer.parseInt(rs.getString("idSess")), rs.getString("nomeSessione"), rs.getBoolean("isActive"));
				}
				else{
					continue;
				}
				s.setAlreadyVoted(rs.getBoolean("alreadyVoted"));
				ss.add(s);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ss;
	}
	
	
	public static void insertUser(){
		String query = "INSERT INTO User() VALUES ;";
		db.insertQuery(query);
	}
	
	
	public static User checkCredentials(String email, String psw){
		String query = "SELECT id,name,surname,email,type FROM user INNER JOIN credential ON idUser=user.id WHERE email LIKE \""+email+"\" AND password = \""+psw+"\";";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			//System.out.println();
			
			if( rowcount == 0){
				System.out.println("Utente non trovato");
				return null;
			}
			
			rs.next();
			User u = new User(rs.getInt("id"), rs.getString("name"), rs.getString("surname"), email, rs.getInt("type"));
			
			System.out.println("Credenziali valide");
			return u;
		} catch (Exception e) {
			System.out.println("Errore controllo credenziali "+e.getMessage());
			//e.printStackTrace();
		}
		
		return null;
	}

	public static Vector<Candidato> getCandidates(Session s) {
		String query = "SELECT c.id,c.name,c.surname,f.id,f.name FROM candidate c INNER JOIN faction f ON f.id=c.factionId INNER JOIN faction_session fs ON fs.idFaction = f.id WHERE fs.idSession = "+s.getId()+";";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			Vector<Candidato> cc = new Vector<Candidato>(rowcount);
			for(int i=0; i<rowcount; i++) {
				rs.next();
				cc.add( new Candidato(  rs.getInt(1), rs.getString(2), rs.getString(3), new Partito(rs.getInt(4), rs.getString(5))  ) );
			}
			
			
			return cc;
		} catch (Exception e) {
			System.out.println("Errore get candidati "+e.getMessage());
			//e.printStackTrace();
		}
		return null;
	}

	public static Vector<Partito> getFactions(Session s) {
		String query = "SELECT f.id,f.name FROM faction f INNER JOIN faction_session fs ON f.id=fs.idFaction WHERE fs.idSession = "+s.getId()+";";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			Vector<Partito> cc = new Vector<Partito>(rowcount);
			for(int i=0; i<rowcount; i++) {
				rs.next();
				cc.add( new Partito( rs.getInt(1), rs.getString(2) ) );
			}
			
			
			return cc;
		} catch (Exception e) {
			System.out.println("Errore get factions "+e.getMessage());
			//e.printStackTrace();
		}
		return null;
	}

	public static void setOrdinalVote(Session s, Vector<Candidato> candidates) {		// come parametri i vettori riordinati dei partiti e dei candidati
		try {
			for(int i=0; i<candidates.size(); i++) {
				Statement statement = db.getDbConnection().createStatement();
				String query = "INSERT INTO vote " + "VALUES (null, " + (candidates.size()-i-1) + ", " + candidates.get(i).getId() + ", " + s.getId() + ")";
				statement.executeUpdate( query );
				
			}
			
			Statement statement = db.getDbConnection().createStatement();
			String query = "INSERT INTO vervote " + "VALUES (null, " + (new userLogged()).getUtente().getId() + ", " + s.getId() + ")";
			statement.executeUpdate( query );
		} catch (Exception e) {
			System.out.println("Errore add cand "+e.getMessage());
			//e.printStackTrace();
		}
		
	}

	public static void setCategoricalVote(Session s, Candidato c) {
		try {
			Statement statement = db.getDbConnection().createStatement();
			statement.executeUpdate("INSERT INTO vote " + "VALUES (null, 1, " + c.getId() + ", " + s.getId() + ")" );
			
			
			Statement statement1 = db.getDbConnection().createStatement();
			statement1.executeUpdate("INSERT INTO vervote " + "VALUES (null, " + (new userLogged()).getUtente().getId() + ", " + s.getId() + ")" );
			
		} catch (Exception e) {
			System.out.println("Errore add cand "+e.getMessage());
			//e.printStackTrace();
		}
		
	}

	public static void setCategoricalPrefVote(Session s, Vector<Candidato> candidates) {
		try {
			for(int i=0; i<candidates.size(); i++) {
				Statement statement = db.getDbConnection().createStatement();
				statement.executeUpdate("INSERT INTO vote " + "VALUES (null, 1, " + candidates.get(i).getId() + ", " + s.getId() + ")" );
			}
			
			
			Statement statement1 = db.getDbConnection().createStatement();
			statement1.executeUpdate("INSERT INTO vervote " + "VALUES (null, " + (new userLogged()).getUtente().getId() + ", " + s.getId() + ")" );
			
		} catch (Exception e) {
			System.out.println("Errore add cand "+e.getMessage());
			//e.printStackTrace();
		}
	}

	public static void setReferendumVote(Session s, int yesOrNo) {
		try {
			Statement statement = db.getDbConnection().createStatement();
			statement.executeUpdate("INSERT INTO vote " + "VALUES (null, " + yesOrNo + ", 0, " + s.getId() + ")" );
			
			Statement statement1 = db.getDbConnection().createStatement();
			statement1.executeUpdate("INSERT INTO vervote " + "VALUES (null, " + (new userLogged()).getUtente().getId() + ", " + s.getId() + ")" );
			
		} catch (Exception e) {
			System.out.println("Errore add cand "+e.getMessage());
			//e.printStackTrace();
		}
	}

	public static Vector<Candidato> getCandidates(Partito partito) {
		String query = "SELECT c.id,c.name,c.surname,f.id,f.name FROM candidate c INNER JOIN faction f ON f.id=c.factionId WHERE f.id="+partito.getId()+";";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			Vector<Candidato> cc = new Vector<Candidato>(rowcount);
			for(int i=0; i<rowcount; i++) {
				rs.next();
				cc.add( new Candidato(  rs.getInt(1), rs.getString(2), rs.getString(3), new Partito(rs.getInt(4), rs.getString(5))  ) );
			}
			
			
			return cc;
		} catch (Exception e) {
			System.out.println("Errore get cand part "+e.getMessage());
			//e.printStackTrace();
		}
		return null;
	}

	public static Vector<Candidato> getCandidates() {
		String query = "SELECT c.id,c.name,c.surname,f.id,f.name FROM candidate c INNER JOIN faction f ON f.id=c.factionId;";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			Vector<Candidato> cc = new Vector<Candidato>(rowcount);
			for(int i=0; i<rowcount; i++) {
				rs.next();
				cc.add( new Candidato(  rs.getInt(1), rs.getString(2), rs.getString(3), new Partito(rs.getInt(4), rs.getString(5))  ) );
			}
			
			
			return cc;
		} catch (Exception e) {
			System.out.println("Errore get cand "+e.getMessage());
			//e.printStackTrace();
		}
		return null;
	}

	public static Vector<Partito> getFactions() {
		String query = "SELECT f.id,f.name FROM faction f;";
		try {
			//System.out.println(query);
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);
			
			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
			}
			
			Vector<Partito> cc = new Vector<Partito>(rowcount);
			for(int i=0; i<rowcount; i++) {
				rs.next();
				cc.add( new Partito( rs.getInt(1), rs.getString(2) ) );
			}
			
			
			return cc;
		} catch (Exception e) {
			System.out.println("Errore get fact "+e.getMessage());
			//e.printStackTrace();
		}
		return null;
	}

	public static void addFaction(String text) {
		try {
			Statement statement = db.getDbConnection().createStatement();
	
			statement.executeUpdate("INSERT INTO faction " + "VALUES (null, \"" + text + "\");");
			
		} catch (Exception e) {
			System.out.println("Errore add fact "+e.getMessage());
			//e.printStackTrace();
		}
	}

	public static void addCandidate(String name, String surname, int factionID) {
		try {
			Statement statement = db.getDbConnection().createStatement();
	
			statement.executeUpdate("INSERT INTO candidate " + "VALUES (null, \"" + name + "\", \"" + surname + "\", " + factionID + ");");
			
		} catch (Exception e) {
			System.out.println("Errore add cand "+e.getMessage());
			//e.printStackTrace();
		}
	}

	public static void addSession(int type, String text, Vector<Integer> v) {
		try {
			Statement statement = db.getDbConnection().createStatement();
			statement.executeUpdate("INSERT INTO session " + "VALUES (null, \"" + text + "\" , 1 , " + type + ");");
			
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery("SELECT MAX(id) FROM session;");
			rs.next();
			int sessId = rs.getInt(1);
			
			for(int i=0; i<v.size(); i++) {
				Statement statement1 = db.getDbConnection().createStatement();
				statement1.executeUpdate("INSERT INTO faction_session " + "VALUES (" + v.get(i) + " , " + sessId + ");");
			}
			
		} catch (Exception e) {
			System.out.println("Errore add sess "+e.getMessage());
			//e.printStackTrace();
		}
	}

	public static int getWinnerRef(Session session) {
		try {
			String query = "SELECT COUNT(v.id), (SELECT COUNT(v.id) FROM v WHERE v.val=1) FROM session s INNER JOIN vote v ON v.idSession=s.id WHERE s.id="+session.getId()+";";
			Statement selectStmt = db.getDbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = selectStmt.executeQuery(query);

			if(rs.next()) {
				if(rs.getInt(2) > (rs.getInt(1)/2))
					return 1;
				else return 2;
			}
			
		} catch (Exception e) {
			System.out.println("Errore add sess "+e.getMessage());
			//e.printStackTrace();
		}
		return 0;
	}

	public static Candidato getWinner(Session session) {
		
		return null;
	}
}
