package application;

public class CategoricalPrefVote extends Session {

	public CategoricalPrefVote(String name) {
		super(name);
	}

	@Override
	public String toString() {
		return null;
	}
	
}
