package application;

public class CategoricalPrefVote extends Session {

	public CategoricalPrefVote(int id, String name, boolean isActive){
		super(id, name, isActive);
	}

	@Override
	public String toString() {
		return null;
	}

	@Override
	public boolean isReferendum() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
