package application;

public class CategoricalVote extends Session{
	public CategoricalVote(String name){
		super(name);
	}
	
	public String toString(){
		String s = "Votazione categorica \""+name+"\"";
		return s;
		
	}
}
