package application;

public class Partito {
	private int id;
	private String nome;
	
	public Partito(int id, String nome) {
		this.id = id;
		this.nome = nome;
	}

}
