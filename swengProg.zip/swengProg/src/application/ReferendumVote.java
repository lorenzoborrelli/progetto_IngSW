package application;

public class ReferendumVote extends Session{
	public ReferendumVote(String name){
		super(name);
	}
	
	public String toString(){
		String s = "Referendum \""+name+"\"";
		return s;
	}
}
