package application;

public class Candidato {

}
